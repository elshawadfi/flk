function createToast(title, store, imgClass)
{
    0==$("#cmd-toastBox").length&&$("<div>",{class:"dc-toast-container",id : "cmd-toastBox", "aria-live":"polite","aria-atomic":"true", "data-autohide":false}).appendTo(document.body);
    var e=$(".dc-toast-container")
    $("<div>",
    {
        class:"dc-toast", id :  "cmd-toast", "data-autohide":false,"role":"alert","aria-live":"assertive","aria-atomic":"true"
    })
    .html("<img src='data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iaXNvLTg4NTktMSI/Pg0KPCEtLSBHZW5lcmF0b3I6IEFkb2JlIElsbHVzdHJhdG9yIDE5LjAuMCwgU1ZHIEV4cG9ydCBQbHVnLUluIC4gU1ZHIFZlcnNpb246IDYuMDAgQnVpbGQgMCkgIC0tPg0KPHN2ZyB2ZXJzaW9uPSIxLjEiIGlkPSJMYXllcl8xIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB4PSIwcHgiIHk9IjBweCINCgkgdmlld0JveD0iMCAwIDUxMiA1MTIiIHN0eWxlPSJlbmFibGUtYmFja2dyb3VuZDpuZXcgMCAwIDUxMiA1MTI7IiB4bWw6c3BhY2U9InByZXNlcnZlIj4NCjxwYXRoIHN0eWxlPSJmaWxsOiNFQkVCRUM7IiBkPSJNNTExLjk5OSwyMjYuOTQ3bC00NC43NjQtNDQuNzY0YzUuNDU0LTE2Ljg4NCw2LjcwNC0zNC44MjMsMy41OTQtNTIuNTE2DQoJYy0zLjg5LTIyLjEzMS0xNC4zNjktNDIuMjUyLTMwLjMwNy01OC4xOWMtMTUuOTM4LTE1LjkzOC0zNi4wNTktMjYuNDE3LTU4LjE5LTMwLjMwN2MtMTcuNjkzLTMuMTEtMzUuNjMyLTEuODU5LTUyLjUxNiwzLjU5NA0KCUwyODUuMDUzLDBMMC4wMDEsMjg1LjA1M2w0NC43NjQsNDQuNzY0Yy01LjQ1MywxNi44ODQtNi43MDQsMzQuODIzLTMuNTk0LDUyLjUxNmMzLjg5LDIyLjEzMSwxNC4zNjksNDIuMjUyLDMwLjMwNyw1OC4xOQ0KCWMxNS45MzgsMTUuOTM4LDM2LjA1OSwyNi40MTcsNTguMTksMzAuMzA3YzE3LjY5NCwzLjEwOSwzNS42MzIsMS44NTksNTIuNTE2LTMuNTk0TDIyNi45NDgsNTEyTDUxMS45OTksMjI2Ljk0N3oiLz4NCjxwYXRoIHN0eWxlPSJmaWxsOiNEQkRBREQ7IiBkPSJNNTExLjk5OSwyMjYuOTQ3bC00NC43NjQtNDQuNzY0YzUuNDU0LTE2Ljg4NCw2LjcwNC0zNC44MjMsMy41OTQtNTIuNTE2DQoJYy0zLjg5LTIyLjEzMS0xNC4zNjktNDIuMjUyLTMwLjMwNy01OC4xOUM0MjMuMDY3LDg4LjkzMyw5NC41ODEsNDE3LjQxOSw3MS40NzcsNDQwLjUyM2MxNS45MzcsMTUuOTM3LDM2LjA1OSwyNi40MTcsNTguMTksMzAuMzA3DQoJYzE3LjY5NCwzLjEwOSwzNS42MzIsMS44NTksNTIuNTE2LTMuNTk0TDIyNi45NDcsNTEyTDUxMS45OTksMjI2Ljk0N3oiLz4NCjxnPg0KCQ0KCQk8cmVjdCB4PSIyMjUuMzAyIiB5PSI1MC43MzUiIHRyYW5zZm9ybT0ibWF0cml4KDAuNzA3MSAwLjcwNzEgLTAuNzA3MSAwLjcwNzEgMTE5LjIyNTQgLTE1Mi43ODUpIiBzdHlsZT0iZmlsbDojNUI1QjVGOyIgd2lkdGg9IjM3LjQ3NyIgaGVpZ2h0PSIzMy41OCIvPg0KCQ0KCQk8cmVjdCB4PSIyNzUuNDA2IiB5PSIxMDAuODM3IiB0cmFuc2Zvcm09Im1hdHJpeCgwLjcwNzEgMC43MDcxIC0wLjcwNzEgMC43MDcxIDE2OS4zMjc4IC0xNzMuNTM5MSkiIHN0eWxlPSJmaWxsOiM1QjVCNUY7IiB3aWR0aD0iMzcuNDc3IiBoZWlnaHQ9IjMzLjU4Ii8+DQoJDQoJCTxyZWN0IHg9IjMyNS41MTUiIHk9IjE1MC45NiIgdHJhbnNmb3JtPSJtYXRyaXgoMC43MDcxIDAuNzA3MSAtMC43MDcxIDAuNzA3MSAyMTkuNDQ2OSAtMTk0LjI5MDgpIiBzdHlsZT0iZmlsbDojNUI1QjVGOyIgd2lkdGg9IjM3LjQ3NyIgaGVpZ2h0PSIzMy41OCIvPg0KPC9nPg0KPGc+DQoJDQoJCTxyZWN0IHg9IjM0MS41MDQiIHk9IjE1Ny41ODciIHRyYW5zZm9ybT0ibWF0cml4KDAuNzA3MSAwLjcwNzEgLTAuNzA3MSAwLjcwNzEgMjI2LjA3MTkgLTE5Ny4wMzE0KSIgc3R5bGU9ImZpbGw6IzQ0NDI0MjsiIHdpZHRoPSIxOC43MzkiIGhlaWdodD0iMzMuNTgiLz4NCgkNCgkJPHJlY3QgeD0iMzc1LjYyNCIgeT0iMjAxLjA3MyIgdHJhbnNmb3JtPSJtYXRyaXgoMC43MDcxIDAuNzA3MSAtMC43MDcxIDAuNzA3MSAyNjkuNTU4MiAtMjE1LjA0NTgpIiBzdHlsZT0iZmlsbDojNDQ0MjQyOyIgd2lkdGg9IjM3LjQ3NyIgaGVpZ2h0PSIzMy41OCIvPg0KCQ0KCQk8cmVjdCB4PSI0MjUuNzUyIiB5PSIyNTEuMTc3IiB0cmFuc2Zvcm09Im1hdHJpeCgwLjcwNzEgMC43MDcxIC0wLjcwNzEgMC43MDcxIDMxOS42Njk0IC0yMzUuODE2NSkiIHN0eWxlPSJmaWxsOiM0NDQyNDI7IiB3aWR0aD0iMzcuNDc3IiBoZWlnaHQ9IjMzLjU4Ii8+DQo8L2c+DQo8Zz4NCgk8cGF0aCBzdHlsZT0iZmlsbDojNTE5MEUzOyIgZD0iTTE2Mi44NzQsMzMwLjY3N2MtMTAuNDY2LDAtMjAuMzA3LTQuMDc2LTI3LjcwOC0xMS40NzdsMCwwYy0xNS4yNzgtMTUuMjc5LTE1LjI3OC00MC4xMzgsMC01NS40MTYNCgkJYzcuNDAyLTcuNDAyLDE3LjI0Mi0xMS40NzgsMjcuNzA4LTExLjQ3OGMxMC40NjcsMCwyMC4zMDksNC4wNzYsMjcuNzA4LDExLjQ3OGM3LjQwMiw3LjQwMSwxMS40NzgsMTcuMjQxLDExLjQ3OCwyNy43MDgNCgkJcy00LjA3NiwyMC4zMDctMTEuNDc4LDI3LjcwOUMxODMuMTgyLDMyNi42MDEsMTczLjM0MSwzMzAuNjc3LDE2Mi44NzQsMzMwLjY3N3ogTTE1OC45MDksMjk1LjQ1NQ0KCQljMS40MjksMS40MjksMy4wOTgsMS42NDMsMy45NjUsMS42NDNjMC44NjgsMCwyLjUzNi0wLjIxMywzLjk2NS0xLjY0MmMxLjQyOS0xLjQyOSwxLjY0Mi0zLjA5OCwxLjY0Mi0zLjk2NQ0KCQljMC0wLjg2Ny0wLjIxMy0yLjUzNi0xLjY0Mi0zLjk2NGMtMS40MjktMS40MjktMy4wOTYtMS42NDMtMy45NjUtMS42NDNjLTAuODY3LDAtMi41MzYsMC4yMTMtMy45NjUsMS42NDMNCgkJQzE1Ni43MjQsMjg5LjcxMiwxNTYuNzI0LDI5My4yNjksMTU4LjkwOSwyOTUuNDU1TDE1OC45MDksMjk1LjQ1NXoiLz4NCgk8cGF0aCBzdHlsZT0iZmlsbDojNTE5MEUzOyIgZD0iTTI4MC41MiwzMjguNTgzYy0xMC40NjcsMC0yMC4zMDctNC4wNzYtMjcuNzA4LTExLjQ3N2wwLDBjLTAuMDAxLDAtMC4wMDEsMC0wLjAwMSwwDQoJCWMtNy40MDEtNy40MDItMTEuNDc4LTE3LjI0Mi0xMS40NzgtMjcuNzA4YzAtMTAuNDY3LDQuMDc3LTIwLjMwNywxMS40NzktMjcuNzA5YzcuNDAxLTcuNDAyLDE3LjI0MS0xMS40NzgsMjcuNzA4LTExLjQ3OA0KCQljMTAuNDY2LDAsMjAuMzA3LDQuMDc2LDI3LjcwOCwxMS40NzdjNy40MDIsNy40MDIsMTEuNDc5LDE3LjI0MiwxMS40NzksMjcuNzA5YzAsMTAuNDY3LTQuMDc3LDIwLjMwNy0xMS40NzksMjcuNzA5DQoJCUMzMDAuODI3LDMyNC41MDgsMjkwLjk4NiwzMjguNTgzLDI4MC41MiwzMjguNTgzeiBNMjgwLjUyLDI4My43OTFjLTAuODY4LDAtMi41MzUsMC4yMTMtMy45NjQsMS42NDINCgkJYy0xLjQzLDEuNDI5LTEuNjQ0LDMuMDk4LTEuNjQ0LDMuOTY1YzAsMC44NjcsMC4yMTQsMi41MzYsMS42NDMsMy45NjRoMC4wMDFjMS40MjgsMS40MjksMy4wOTUsMS42NDIsMy45NjQsMS42NDINCgkJYzAuODY3LDAsMi41MzYtMC4yMTMsMy45NjUtMS42NDNjMS40MjktMS40MjksMS42NDMtMy4wOTYsMS42NDMtMy45NjRjMC0wLjg2Ny0wLjIxNC0yLjUzNi0xLjY0My0zLjk2NQ0KCQlDMjgzLjA1NSwyODQuMDA0LDI4MS4zODcsMjgzLjc5MSwyODAuNTIsMjgzLjc5MXoiLz4NCjwvZz4NCjxnPg0KCQ0KCQk8cmVjdCB4PSIxMzguMTE2IiB5PSIyNzMuNTk2IiB0cmFuc2Zvcm09Im1hdHJpeCgtMC4xMDYxIC0wLjk5NDQgMC45OTQ0IC0wLjEwNjEgLTQzLjYyNjcgNTQxLjU1MzkpIiBzdHlsZT0iZmlsbDojRTE3NDRFOyIgd2lkdGg9IjE2Ni45ODYiIGhlaWdodD0iMzMuNTgyIi8+DQoJPHBhdGggc3R5bGU9ImZpbGw6I0UxNzQ0RTsiIGQ9Ik0xNjIuODc0LDMzMC42NzdjLTEwLjQ2NiwwLTIwLjMwNy00LjA3Ni0yNy43MDgtMTEuNDc3bDAsMGMtMTUuMjc4LTE1LjI3OS0xNS4yNzgtNDAuMTM4LDAtNTUuNDE2DQoJCWM3LjQwMi03LjQwMiwxNy4yNDItMTEuNDc4LDI3LjcwOC0xMS40NzhjMTAuNDY3LDAsMjAuMzA5LDQuMDc2LDI3LjcwOCwxMS40NzhjNy40MDIsNy40MDEsMTEuNDc4LDE3LjI0MSwxMS40NzgsMjcuNzA4DQoJCXMtNC4wNzYsMjAuMzA3LTExLjQ3OCwyNy43MDlDMTgzLjE4MiwzMjYuNjAxLDE3My4zNDEsMzMwLjY3NywxNjIuODc0LDMzMC42Nzd6IE0xNTguOTA5LDI5NS40NTUNCgkJYzEuNDI5LDEuNDI5LDMuMDk4LDEuNjQzLDMuOTY1LDEuNjQzYzAuODY4LDAsMi41MzYtMC4yMTMsMy45NjUtMS42NDJjMS40MjktMS40MjksMS42NDItMy4wOTgsMS42NDItMy45NjUNCgkJYzAtMC44NjctMC4yMTMtMi41MzYtMS42NDItMy45NjRjLTEuNDI5LTEuNDI5LTMuMDk2LTEuNjQzLTMuOTY1LTEuNjQzYy0wLjg2NywwLTIuNTM2LDAuMjEzLTMuOTY1LDEuNjQzDQoJCUMxNTYuNzI0LDI4OS43MTIsMTU2LjcyNCwyOTMuMjY5LDE1OC45MDksMjk1LjQ1NUwxNTguOTA5LDI5NS40NTV6Ii8+DQo8L2c+DQo8Zz4NCgk8cGF0aCBzdHlsZT0iZmlsbDojREQ1MzIzOyIgZD0iTTI4MC41MiwzMjguNTgzYy0xMC40NjcsMC0yMC4zMDctNC4wNzYtMjcuNzA4LTExLjQ3N2wwLDBjLTAuMDAxLDAtMC4wMDEsMC0wLjAwMSwwDQoJCWMtNy40MDEtNy40MDItMTEuNDc4LTE3LjI0Mi0xMS40NzgtMjcuNzA4YzAtMTAuNDY3LDQuMDc3LTIwLjMwNywxMS40NzktMjcuNzA5YzcuNDAxLTcuNDAyLDE3LjI0MS0xMS40NzgsMjcuNzA4LTExLjQ3OA0KCQljMTAuNDY2LDAsMjAuMzA3LDQuMDc2LDI3LjcwOCwxMS40NzdjNy40MDIsNy40MDIsMTEuNDc5LDE3LjI0MiwxMS40NzksMjcuNzA5YzAsMTAuNDY3LTQuMDc3LDIwLjMwNy0xMS40NzksMjcuNzA5DQoJCUMzMDAuODI3LDMyNC41MDgsMjkwLjk4NiwzMjguNTgzLDI4MC41MiwzMjguNTgzeiBNMjgwLjUyLDI4My43OTFjLTAuODY4LDAtMi41MzUsMC4yMTMtMy45NjQsMS42NDINCgkJYy0xLjQzLDEuNDI5LTEuNjQ0LDMuMDk4LTEuNjQ0LDMuOTY1YzAsMC44NjcsMC4yMTQsMi41MzYsMS42NDMsMy45NjRoMC4wMDFjMS40MjgsMS40MjksMy4wOTUsMS42NDIsMy45NjQsMS42NDINCgkJYzAuODY3LDAsMi41MzYtMC4yMTMsMy45NjUtMS42NDNjMS40MjktMS40MjksMS42NDMtMy4wOTYsMS42NDMtMy45NjRjMC0wLjg2Ny0wLjIxNC0yLjUzNi0xLjY0My0zLjk2NQ0KCQlDMjgzLjA1NSwyODQuMDA0LDI4MS4zODcsMjgzLjc5MSwyODAuNTIsMjgzLjc5MXoiLz4NCgk8cG9seWdvbiBzdHlsZT0iZmlsbDojREQ1MzIzOyIgcG9pbnRzPSIyMTMuNzg4LDM3NS4xNzMgMjA2LjM2OSwzMDUuNjMxIDIzNi44ODMsMjc1LjExNyAyNDcuMTc3LDM3MS42MTEgCSIvPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPC9zdmc+DQo=' /><div class='dc-toast-content'><div class='dc-toast-header'><strong>"
    +title+"</strong><button type='button' class='dc-close' data-dismiss='toast' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div><div class='dc-toast-body'> Explore our handpicked coupons and deals for <strong>"
    +store+"</strong>  and save big on your next purchase.<br><p>To know more, press <button type='button'><img src="+imgClass+"></button> icon in your browser.</p></div></div>").appendTo(e).toast("show"),$("#cmd-toastBox").on("hidden.bs.toast",function(){$(this).toast("dispose").remove()
    });
    var link = document.createElement("link");
    link.href = chrome.extension.getURL("fix.css");
    link.type = "text/css";
    link.rel = "stylesheet";
    document.getElementsByTagName("head")[0].appendChild(link);
}
window.onload = function()
{
    setTimeout(function()
    {
        chrome.storage.local.get(['response'], function(file)
        {
            var data = file.response, title ='';
            if(data.code == 'success')
            {
                var string = data.store.store_url.replace("http://", "").replace("https://", "").replace("www.", "").split(".")[0];
                var store = string.charAt(0).toUpperCase() + string.slice(1);
                var imgClass = "'chrome-extension://"+chrome.runtime.id+"/icons/logo.png'"
                if(data.coupons.length > 0 && data.cashback.status == false)
                {
                    title = "Found "+(data.coupons).length+" Offers To Use!";
                    createToast(title, store, imgClass);
                    console.log("Showing Toast >0nf");
                    //toast with coupons only
                }
                else if(data.coupons.length > 0 && data.cashback.status == true)
                {
                    title = "Found "+(data.coupons).length+" Offers To Use + "+data.cashback.message;
                    createToast(title, store, imgClass);
                    console.log("Showing Toast >0nt");
                    //toast with both coupons and cashback
                }
                else if(data.coupons.length == 0 && data.cashback.status == true)
                {
                    //toast with both titles
                    title = data.cashback.message + " available!"
                    createToast(title, store, imgClass);
                    console.log("Showing Toast 0nt");
                }
            }
            else
            {}
        })
    }, 1000);
};
