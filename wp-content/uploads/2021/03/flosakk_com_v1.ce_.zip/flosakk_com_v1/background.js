const manifest = chrome.runtime.getManifest();
const couponEndpoint = "wp-json/cmd/v1/getStoreByDomain/?domain=";
const loginEndpoint = "wp-json/cmd/v1/getUser";
//async function fetchStoreResponse(data, type) ==> fetch JSON response from API
//data ==>  current tab URL to extract domain name 
//type ==> type of event fired (tabActivated/tab update) for badge setting

async function fetchStoreResponse(data, type)
{
    var domName = data.replace("www.", '').replace("http://", "").replace("https://", "").split(/[/?#]/)[0];
    const fetchData = await fetch(manifest.homepage_url + couponEndpoint + domName, 
    {
        method: 'GET', 
        headers : 
        {
            "Access-Control-Allow-Origin" : manifest.homepage_url
        }
    })
    const response = await fetchData.json();
    //console.log(response);
    chrome.tabs.query ({active :true, currentWindow : true}, function(tabs)
    {
        if(type == 1 && response.code === 'success' && (response.coupons).length > 0) 
        {
            (chrome.browserAction.setBadgeText({text : ((response.coupons).length).toString(), tabId : tabs[0].id})) 
        }
        else
        {
            chrome.browserAction.setBadgeText({text : "", tabId : tabs[0].id})
        }
        if(response.code === 'success' && (response.coupons).length > 0)
        {
            chrome.browserAction.setBadgeText({text : ((response.coupons).length).toString(), tabId : tabs[0].id});
        }
    })
    chrome.storage.local.set({response});
}

/*******Event Listeners for tab actions (activated/updated)*******/

chrome.tabs.onActivated.addListener(function()
{
    chrome.tabs.query({active :  true, currentWindow : true}, function(tabs)
    { 
        userStat();
        fetchStoreResponse(tabs[0].url, 1);
    })
    
});
chrome.tabs.onUpdated.addListener(function(id, info, tab)
{
    userStat();
    if (info.status == 'complete' && tab.url != undefined && tab.status === 'complete') 
    {
        fetchStoreResponse(tab.url, 0);
    }   
})

// function userStat() ==> function to get login status
function userStat()
{
    fetch(manifest.homepage_url + loginEndpoint, 
    {
        method : 'GET',
        headers :  
        {
            'Access-Control-Allow-Origin' : manifest.homepage_url
        }
    }).then(reply => reply.json()).then(function(reply)
    {
        chrome.storage.local.set({reply});
    })
}
chrome.runtime.onMessage.addListener(function(msg, sender, sendResponse)
{
    chrome.storage.onChanged.addListener(function(changes, namespace)
    {
        for(key in changes)
        {
            if(key === 'reply' && changes.reply.newValue.logged_in == true && msg.pos == 1)
            {
                chrome.tabs.query({active :true}, function(tabs)
                {
                    chrome.tabs.remove(tabs[0].id);
                    chrome.tabs.update(msg.cID, {active : true});
                });
            }
            else if(key === 'reply' && changes.reply.newValue.logged_in == false && msg.pos == 2)
            {
                chrome.tabs.query({active :true}, function(tabs)
                {
                    chrome.tabs.remove(tabs[0].id);
                    chrome.tabs.update(msg.cID, {active : true});
                });
            }
        }
    })
})

