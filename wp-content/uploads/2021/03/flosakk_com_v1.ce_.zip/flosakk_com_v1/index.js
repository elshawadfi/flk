main_script();
function main_script()
{
    const manifest = chrome.runtime.getManifest();
    document.addEventListener('DOMContentLoaded', fNavbar);
    function fNavbar()
    {
        let navbar = document.querySelectorAll('.p-2');
        navbar.forEach(item => item.addEventListener('click', function()
        {
            if(item.id === 'acct-btn')
            {
                chrome.storage.local.get(['reply'], function(login2)
                {
                    if(login2.reply.logged_in == true)
                    {
                        item.removeEventListener('click', fNavbar, true);
                    }
                    else
                    {
                        chrome.tabs.query({active :true}, function(tabs)
                        {
                            chrome.tabs.create({index : tabs[0].index + 1, url : manifest.homepage_url +'wp-login.php?redirect_to=%2F'});
                            chrome.runtime.sendMessage({pos : 1, cID : tabs[0].id});
                        })
                    }
                })
            }
            else if(item.id === 'settg-btn')
            {
                chrome.storage.local.get(['reply'], function(file)
                {
                    item.addEventListener('click', function()
                    {
                        if(file.reply.logged_in == true)
                        {
                            chrome.tabs.query({active : true}, function(tabs)
                            {
                                chrome.tabs.create({url : manifest.homepage_url + "wp-admin/profile.php", index : tabs[0].index +1});
                            });
                        }
                        else
                        {}
                    });
                });
            }
            else if(item.id === "close-btn")
            {
                window.close();
            }
           
        }))
    }           
    chrome.storage.local.get(['reply'], function(login)
    {
        if(login.reply.logged_in == true)
        {
            document.getElementById('acct-btn').removeEventListener('click', fNavbar);
            document.getElementById('settg-btn').style.display = 'block';

            var accountBtn = document.getElementById('acct-btn');
            var settingBtn = document.getElementById('settg-btn');

            accountBtn.innerHTML = "<p class='user-name'>"+login.reply.details.display_name.charAt(0)+"</p>";     

            accountBtn.classList.add('dropdown-toggle');
            // accountBtn.classList.add('user-name');
            accountBtn.setAttribute("data-hover", "dropdown");

            settingBtn.classList.add('dropdown-toggle');
            settingBtn.setAttribute("data-hover", "dropdown");

            /*************Settings DropDown************* */

            var sList = document.createElement('ul');               sList.className = "dropdown-menu";
            var txn = document.createElement('li');                 txn.className = "drop txn";
            var a3 = document.createElement('a');                   a3.innerHTML = "Transactions";
            var wdl = document.createElement('li');                 wdl.className = "drop wdl";
            var a4 = document.createElement('a');                   a4.innerHTML = "Withdrawals"; 

            chrome.tabs.query({active :true}, function(tabs)
            {
                txn.addEventListener('click', function()
                {
                    chrome.tabs.create({url : manifest.homepage_url+"wp-admin/admin.php?page=transactions", index : tabs[0].index +1});
                })
                wdl.addEventListener('click', function()
                {
                    chrome.tabs.create({url :  manifest.homepage_url + 'wp-admin/admin.php?page=withdrawals', index :tabs[0].index + 1});
                })
            });
            txn.appendChild(a3);
            wdl.appendChild(a4);
            sList.appendChild(txn);
            sList.appendChild(wdl);                         
            settingBtn.appendChild(sList);

            /**************Account DropDown*************/

            var aList = document.createElement('ul');               aList.className = "dropdown-menu";
            var profile = document.createElement('li');             profile.className = "drop profile";
            var a1 = document.createElement('a');                   a1.innerHTML = "Profile";
            var logout = document.createElement('li');              logout.className = "drop logout";
            var a2 = document.createElement('a');                   a2.innerHTML = "Logout"; 
            chrome.tabs.query({active :true}, function(tabs)
            {
                profile.addEventListener('click', function()
                {
                    chrome.tabs.create({url : manifest.homepage_url + "wp-admin/profile.php", index : tabs[0].index +1});
                })
                logout.addEventListener('click', function()
                {
                    chrome.tabs.create({url :  manifest.homepage_url + 'wp-login.php?action=logout&amp;_wpnonce=ef981aa91c', index :tabs[0].index + 1});
                    chrome.runtime.sendMessage({pos : 2, cID : tabs[0].id});
                })
            });
            profile.appendChild(a1);
            logout.appendChild(a2);
            aList.appendChild(profile);
            aList.appendChild(logout);                         
            accountBtn.appendChild(aList);
        }
        else 
        {
            var accountBtn = document.getElementById('acct-btn');
            document.getElementById('settg-btn').style.display = 'none';
        }
    })          
    /********Top Right navigation bar function end *********/
    /********Function to empty division********** */ 
    function deleteChild() 
    { 
        var e = document.querySelector(".cmd-tabContent"); 
        var first = e.firstElementChild; 
        while (first) 
        { 
            first.remove(); 
            first = e.firstElementChild; 
        } 
        var e = document.querySelector(".cmd-cashbacks"); 
        var first = e.firstElementChild; 
        while (first) 
        { 
            first.remove(); 
            first = e.firstElementChild; 
        }
    }
    function cbk_btn(data)
    {
        let cbk = document.createElement('div');
        cbk.className = "cashbacks";
        var cbkHeader = document.createElement('p');
        cbkHeader.innerHTML = "<img src='icons/cashback.svg'> Cashbacks";
        chrome.storage.local.get(['reply'], function(login)
        {
            var status = login.reply.logged_in;
            if(status == false && data.cashback.status == true)
            {
                var msg = document.createElement("p");
                msg.innerHTML = data.cashback.message + " available. Login to avail them!";
                var  btn = document.createElement('button');            btn.type = "button"; btn.id  = "loginBtn";
                btn.className = "btn";            btn.innerHTML = "Login";
                btn.addEventListener('click', function()
                {
                    chrome.tabs.query({active :true}, function(tabs)
                    {
                        chrome.tabs.create({index : tabs[0].index + 1, url : manifest.homepage_url + 'wp-login.php?redirect_to=%2F'});
                        chrome.runtime.sendMessage({pos : 1, cID : tabs[0].id});
                    })
                })
                cbk.appendChild(cbkHeader);
                cbk.appendChild(msg);
                cbk.appendChild(btn)
                document.getElementById("cmd-cbkDiv").appendChild(cbk);
            }
            else if(status == true && data.cashback.status == true)
            {
                var cbTitle = document.createElement("p");  
                var activate_btn = document.createElement('a');        activate_btn.style.display = 'none';
                let details = document.createElement("a");   
                let info = document.createElement("i");      info.className = "fa fa-info-circle"; 
                var btnsDiv = document.createElement('div');      
                chrome.tabs.query({active : true, currentWindow : true}, function(tabs)
                {
                    chrome.storage.local.get(['response'], function(file)
                    {
                        var data = file.response, ctr = 0;
                        chrome.cookies.get({url : manifest.homepage_url, name : "storesVisited"}, function(cookie)
                        {
                            if(cookie != null)
                            {
                                if((cookie.value).includes(data.store.slug+'|'))
                                {
                                    ctr = 1;
                                    cbTitle.innerHTML = "Cashbacks Activated, please continue shopping in this window."
                                    details.innerHTML = "See Details ";
                                    details.appendChild(info);
                                    details.className = "p-0 btn";
                                    details.href = data.cashback.details;   
                                    details.target = "_blank";
                                }
                                if(ctr ==  0)
                                {
                                    cbTitle.innerHTML = data.cashback.message + " available."
                                    details.innerHTML = "See Details "; 
                                    details.href = data.cashback.details;   
                                    details.target = "_blank";   
                                    details.className = "px-0 btn ml-4";    
                                    details.appendChild(info);
                                    activate_btn.innerHTML = "Activate";
                                    activate_btn.className = "btn";      activate_btn.style.display = 'inline-block';
                                    activate_btn.addEventListener('click', function()
                                    {
                                        var oldValue = cookie.value;
                                        if(data.store.store_aff_url)
                                        {
                                            var aff_link = data.store.store_aff_url.replace("[user]", login.reply.details.id)
                                        }
                                        else 
                                        {
                                            var aff_link = data.store.store_url;
                                        }
                                        chrome.cookies.set({url : manifest.homepage_url, name : "storesVisited", value : oldValue + data.store.slug+"|" })
                                        chrome.tabs.create({url : aff_link, active :true, index : tabs[0].index + 1})
                                    })
                                }
                            }
                            else 
                            {
                                cbTitle.innerHTML = data.cashback.message + " available."
                                details.innerHTML = "See Details ";   
                                details.href = data.cashback.details;   
                                details.target = "_blank"; 
                                details.className = "px-0 btn ml-4";    
                                details.appendChild(info);
                                activate_btn.innerHTML = "Activate";
                                activate_btn.className = "btn";      activate_btn.style.display = 'inline-block';
                                activate_btn.addEventListener('click', function()
                                {
                                    if(data.store.store_aff_url)
                                    {
                                        var aff_link = data.store.store_aff_url.replace("[user]", login.reply.details.id)
                                    }
                                    else 
                                    {
                                        var aff_link = data.store.store_url;
                                    }
                                    chrome.tabs.create({url : aff_link, active :true, index : tabs[0].index + 1});
                                    chrome.cookies.set({url : manifest.homepage_url, name : "storesVisited", value : data.store.slug + "|" });
                                })
                            }
                        });
                    });
                });
                cbk.appendChild(cbkHeader);
                cbk.appendChild(cbTitle);
                btnsDiv.appendChild(activate_btn);
                btnsDiv.appendChild(details);
                cbk.appendChild(btnsDiv);
                document.getElementById("cmd-cbkDiv").appendChild(cbk);
            }
        })
    }
    /********Function to empty division end********** */ 
    /********Main Function for Data Display********** */ 
    fnTabSwitch();
    function fnTabSwitch()
    {
        var nCoupons=0, nDeals=0;
        chrome.storage.local.get(['response'], function(file)
        {
            var data = file.response;
            if(data.code === "success" && (data.coupons).length > 0)
            {
                cbk_btn(data);
                allbtn();
                function allbtn()
                {
                    for(i = 0; i< (data.coupons).length; i++)
                    {
                        if(data.coupons[i].type == "code" )
                        {
                            addCouponElement(data.coupons[i]);
                        }
                        else
                        {
                            addDealElement(data.coupons[i]);
                        }
                    }
                } 
                tabs = document.querySelectorAll(".nav-link"); 
                tabs.forEach(item => 
                {
                    item.addEventListener("click", function()
                    {
                        if(item.id == "coupon-btn")
                        {
                            if(document.getElementsByClassName("cmd-tabContent").length == 0 && document.getElementsByClassName("cmd-cashbacks").length == 0)
                            {
                                for(i = 0; i< (data.coupons).length; i++)
                                {
                                    if(data.coupons[i].type == "code")
                                    {
                                        nCoupons += 1;
                                        addCouponElement(data.coupons[i]);
                                    }
                                    else
                                    {
                                        continue;
                                    }
                                }
                                if(nCoupons == 0)
                                {
                                    let noEl = document.createElement("div");
                                    noEl.class = "noCoupons";
                                    let message = document.createElement("h4");
                                    message.innerHTML  = "Could not find any coupons for this website.";
                                    noEl.appendChild(message);
                                    document.getElementById("accordion").appendChild(noEl);
                                }
                            }
                            else
                            {
                                deleteChild();
                                for(i = 0; i< (data.coupons).length; i++)
                                {
                                    if(data.coupons[i].type == "code")
                                    {
                                        nCoupons += 1;
                                        addCouponElement(data.coupons[i]);
                                    }
                                    else
                                    {
                                        continue;
                                    }
                                }
                                if(nCoupons == 0)
                                {
                                    let noEl = document.createElement("div");
                                    noEl.class = "noCoupons";
                                    let message = document.createElement("h4");
                                    message.innerHTML  = "Could not find any coupons for this website.";
                                    noEl.appendChild(message);
                                    document.getElementById("accordion").appendChild(noEl);
                                }
                            }
                        }
                        else if(item.id == "deal-btn")
                        {
                            if(document.getElementsByClassName("cmd-tabContent").length == 0 && document.getElementsByClassName("cmd-cashbacks").length == 0)
                            {
                                for(i = 0; i< (data.coupons).length; i++)
                                {
                                    if(data.coupons[i].type == "deal")
                                    {
                                        nDeals += 1;
                                        addDealElement(data.coupons[i]);
                                    }
                                    else
                                    {
                                        continue;
                                    }
                                }
                                if(nDeals == 0)
                                {
                                    let noEl = document.createElement("div");
                                    noEl.class = "noCoupons";
                                    let message = document.createElement("h4");
                                    message.innerHTML  = "Could not find any deals for this website.";
                                    noEl.appendChild(message);
                                    document.getElementById("accordion").appendChild(noEl);
                                }
                            }
                            else
                            {
                                deleteChild();
                                for(i = 0; i< (data.coupons).length; i++)
                                {
                                    if(data.coupons[i].type == "deal")
                                    {
                                        nDeals += 1;
                                        addDealElement(data.coupons[i]);
                                    }
                                    else
                                    {
                                        continue;
                                    }
                                }
                                if(nDeals == 0)
                                {
                                    let noEl = document.createElement("div");
                                    noEl.class = "noCoupons";
                                    let message = document.createElement("h4");
                                    message.innerHTML  = "Could not find any deals for this website.";
                                    noEl.appendChild(message);
                                    document.getElementById("accordion").appendChild(noEl);
                                }
                            }
                        }
                        else
                        {
                            if(document.getElementsByClassName("cmd-tabContent").length == 0 && document.getElementsByClassName("cmd-cashbacks").length == 0)
                            {
                                cbk_btn(data);
                                allbtn();
                            }
                            else
                            {
                                deleteChild();
                                cbk_btn(data);
                                allbtn();
                            }
                        }
                    })
                })
            }
            else
            {
                let noEl = document.createElement("div");
                noEl.class = "noCoupons";
                let message = document.createElement("h4");
                message.innerHTML  = "Could not find any offer for this website.";
                noEl.appendChild(message);
                document.getElementById("accordion").appendChild(noEl);
            }
        });
    }
    /********Main Function for Data Display Complete********** */ 
    /*********Function for adding Coupon Elements ********/
    const arr = [];
    function addCouponElement(couponObject)
    {
        let coupon = document.createElement('div');
        coupon.className = "offers card";
        let row1 = document.createElement('div');    row1.className="card-title mb-0"                 
        let title = document.createElement('p');
        let ver_img = document.createElement('img');
        setAttributes(ver_img, {'src': 'icons/verified.svg', 'data-toggle': 'tooltip', 'data-placement': 'top', 
        'title': 'Verified on: ' + couponObject.verified_on}); 
        title.innerHTML = couponObject.title+ ' ';
        let bg_img = document.createElement('div');       bg_img.className = 'bg';
        let details = document.createElement('a');    details.className = "card-link mr-auto"
        var collapseID = "#collapseContent" + (++document.getElementById('accordion').children.length);
        setAttributes(details, {'href': collapseID, 'data-toggle': 'collapse', 'role': 'button', 'aria-expanded': 'false',
        'aria-controls': collapseID});
        details.innerHTML = "See Details "
        var angle = document.createElement('i');        angle.className = "fas fa-chevron-down";      
        angle.id = "d" + couponObject.ID        
        angle.style.cssText = "font-size: 11px";
        details.append(angle);
        details.addEventListener('click', function()
        {
            angle.classList.toggle('img-rotate');
        });
        let dDesc = document.createElement('p');                dDesc.innerHTML = couponObject.description;
        let validity = document.createElement('p');
        let verified = document.createElement('p');
        verified.innerHTML = "<b>Verified on:</b> " +  couponObject.verified_on;
        validity.innerHTML = "<b>Valid Till:</b> " +  couponObject.valid_till;
        let row2 = document.createElement('div');    row2.className="btn-container"
        let rDiv = document.createElement('div');    rDiv.className = 'coupon-container d-flex align-items-center'
        let btn = document.createElement('button');         btn.type = "button"; btn.id  = "btn";
        btn.className = "btn coupon-btn";             btn.innerHTML = "Get Code!";         btn.style.visibility = "hidden";
        let coupon_code = document.createElement('p');
        coupon_code.innerHTML = couponObject.code + " ";
        coupon_code.className = "coupon-code btn";
        coupon_code.id = "coupon-code";
        var copyBtn = document.createElement('i');           copyBtn.className = 'fa fa-clone';
        copyBtn.style.color = "#767884";
        copyBtn.id = 'copy-button' + couponObject.ID;           copyBtn.style.display = 'none';
        setAttributes(copyBtn, {'data-toggle': 'tooltip', 'data-placement': 'top', 'title': 'Click to Copy!'});
        coupon_code.appendChild(copyBtn);
        let row3 = document.createElement('div'); 
        row3.className = "card-body collapse";    row3.id = 'collapseContent' + (++document.getElementById('accordion').children.length);
        var flag = 0;
        arr.push(couponObject.ID);
        chrome.storage.local.get(['reply'], function(file)
        {
            const loginStat = file.reply;
            chrome.tabs.query({active :  true}, function(tabs)
            {    
                chrome.storage.local.get(['response'], function(data)
                {
                    const store = data.response.store;
                    chrome.cookies.get({url : manifest.homepage_url, name : "storesVisited"}, function(cookie)
                    {
                        if(cookie != null)
                        {
                            if((cookie.value).includes(store.slug+'|'))
                            {
                                flag = 1;
                                copyBtn.style.display = 'inline-block';
                                copyBtn.addEventListener('click', function()
                                {
                                    copy(couponObject.code);
                                    for(i=0, l=arr.length; i<l; i++)
                                    {
                                        document.getElementById('copy-button'+arr[i]).style.color = "767884";
                                        setAttributes(document.getElementById('copy-button'+arr[i]), {'data-toggle': 'tooltip', 'data-placement': 'top', 
                                        'title': 'Click to Copy!'});
                                    }
                                    copyBtn.style.color = 'f28f5a';
                                    setAttributes(copyBtn, {'data-toggle': 'tooltip', 'data-placement': 'top', 'title': 'Copied!'});
                                });
                            }
                            if(flag ==  0)
                            {
                                btn.style.visibility = "visible";
                                btn.innerHTML = "Get Code!";  
                                btn.addEventListener("click", function()
                                {
                                    btn.style.clipPath = 'polygon(0 0,0 0,0 100%, 0 100%)';
                                    btn.style.visibility = "hidden";
                                    var oldValue = cookie.value
                                    chrome.cookies.set({url : manifest.homepage_url, name : "storesVisited", value : oldValue + store.slug + "|" })
                                    copyBtn.style.display = 'inline-block';
                                    copyBtn.addEventListener('click', function()
                                    {
                                        copy(couponObject.code);
                                        for(i=0, l=arr.length; i<l; i++)
                                        {
                                            document.getElementById('copy-button'+arr[i]).style.color = "767884";
                                            setAttributes(document.getElementById('copy-button'+arr[i]), {'data-toggle': 'tooltip', 'data-placement': 'top', 
                                            'title': 'Click to Copy!'});
                                        }
                                        copyBtn.style.color = 'f28f5a';
                                        setAttributes(copyBtn, {'data-toggle': 'tooltip', 'data-placement': 'top', 'title': 'Copied!'});
                                    });
                                    if(loginStat.logged_in == true)
                                    {
                                        chrome.tabs.create({active : false, url : (couponObject.url).replace('[user]', (loginStat.details.id)) , index :tabs[0].index + 1});
                                    }
                                    else
                                    {
                                        chrome.tabs.create({active : false, url : couponObject.url, index : tabs[0].index + 1});
                                    }
                                });
                            }
                        }
                        else
                        {
                            btn.style.visibility = "visible";
                            btn.innerHTML = "Get Code!";  
                            setAttributes(coupon_code, {'data-toggle': 'tooltip', 'data-placement': 'top', 
                            'title': 'Copied!'});
                            btn.addEventListener("click", function()
                            {
                                btn.style.clipPath = 'polygon(0 0,0 0,0 100%, 0 100%)';
                                btn.style.visibility = "hidden";
                                chrome.cookies.set({url : manifest.homepage_url, name : "storesVisited", value : store.slug + "|"});
                                copyBtn.style.display = 'inline-block';
                                copyBtn.addEventListener('click', function()
                                {
                                    copy(couponObject.code);
                                    for(i=0, l=arr.length; i<l; i++)
                                    {
                                        document.getElementById('copy-button'+arr[i]).style.color = "767884";
                                        setAttributes(document.getElementById('copy-button'+arr[i]), {'data-toggle': 'tooltip', 'data-placement': 'top', 
                                        'title': 'Click to Copy!'});
                                    }
                                    copyBtn.style.color = 'f28f5a';
                                    setAttributes(copyBtn, {'data-toggle': 'tooltip', 'data-placement': 'top', 'title': 'Copied!'});
                                });
                                setTimeout(function() {
                                    rDiv.style.width='auto';
                                }, (0.5* 1000));
                                if(loginStat.logged_in == true)
                                {
                                    chrome.tabs.create({active : false, url : (couponObject.url).replace('[user]', (loginStat.details.id)) , index :tabs[0].index + 1});
                                }
                                else
                                {
                                    chrome.tabs.create({active : false, url : couponObject.url, index :  tabs[0].index + 1});
                                }
                            })
                        }
                    })
                })
                
            });
        });
        row1.appendChild(title);
        row2.appendChild(details);
        row2.appendChild(rDiv);
        rDiv.appendChild(coupon_code);
        rDiv.appendChild(btn);
        row3.appendChild(title.cloneNode(true));
        row3.appendChild(dDesc);
        row3.appendChild(validity);
        if(couponObject.verified_on != null)
        {
            row3.appendChild(verified);
            title.appendChild(ver_img);
        }
        coupon.appendChild(row1);
        coupon.appendChild(bg_img);
        coupon.appendChild(row2);
        coupon.appendChild(row3);
        document.getElementById("accordion").appendChild(coupon);
    }
    /*********Function for adding Coupon Elements Complete********/
    /*********Function for adding Deal Elements ********/
    function addDealElement(dealObject)
    {
        let deal = document.createElement('div');           deal.className = "offers card";
        let row1 =  document.createElement('div');          row1.className = "card-title mb-0";
        let title = document.createElement('p');          
        let ver_img = document.createElement('img');
        setAttributes(ver_img, {'src': 'icons/verified.svg', 'data-toggle': 'tooltip', 'data-placement': 'top', 
        'title': 'Verified on: ' + dealObject.verified_on}); 
        ver_img.style.cssText = 'cursor: pointer';
        title.innerHTML = dealObject.title+ ' ';
        let bg_img = document.createElement('div');       bg_img.className = 'bg';
        let details = document.createElement('a');    details.className = "card-link mr-auto"
        var collapseID = "#collapseContent" + (++document.getElementById('accordion').children.length)
        setAttributes(details, {'href': collapseID, 'data-parent' : '#accordion', 'data-toggle': 'collapse', 'role': 'button', 'aria-expanded': 'false',
        'aria-controls': collapseID});
        details.innerHTML = "See Details "
        var angle = document.createElement('i');        angle.className = "fas fa-chevron-down";      
        angle.id = "d" + dealObject.ID
        angle.style.cssText = "font-size: 11px";
        details.append(angle);
        details.addEventListener('click', function()
        {
            angle.classList.toggle('img-rotate');
        });   
        let dDesc = document.createElement('p');                dDesc.innerHTML = dealObject.description;
        let validity = document.createElement('p');      
        validity.innerHTML = "<b>Valid Till:</b> " + dealObject.valid_till; 
        let verified = document.createElement('p');
        verified.innerHTML = "<b>Verified on:</b> " +  dealObject.verified_on;
        let row2 = document.createElement('div');           row2.className = "btn-container";
        let btn = document.createElement('button');         btn.type = "button"; btn.id  = "btn";
        btn.className = "btn";             btn.innerHTML = "Get Deal!";
        let row3 = document.createElement('div');       
        row3.className = "card-body collapse";    row3.id = 'collapseContent' + (++document.getElementById('accordion').children.length);
        var flag=0;
        chrome.storage.local.get(['reply'], function(file)
        {
            const loginStat = file.reply;
            chrome.tabs.query({active :  true}, function(tabs)
            {
                chrome.storage.local.get(['response'], function(data)
                {
                    const store = data.response.store;
                    chrome.cookies.get({url : manifest.homepage_url, name : "storesVisited"}, function(cookie)
                    {
                        btn.addEventListener('click', function()
                        {        
                            if(cookie != null)
                            {
                                if((cookie.value).includes(store.slug+'|'))
                                {
                                    flag = 1;
                                    if(loginStat.logged_in == true)
                                    {
                                        chrome.tabs.create({active :  false, url : (dealObject.url).replace('[user]', (loginStat.details.id))});
                                    }
                                    else
                                    {
                                        chrome.tabs.create({active : false, url : dealObject.url});
                                    }
                                }
                                if(flag ==  0)
                                {
                                    btn.addEventListener("click", function()
                                    {
                                        var oldValue = cookie.value
                                        chrome.cookies.set({url : manifest.homepage_url, name : "storesVisited", value : oldValue + store.slug +"|" });
                                    });
                                }
                            }
                            else 
                            {
                                chrome.cookies.set({url : manifest.homepage_url, name : "storesVisited", value : store.slug +"|"});
                                if(loginStat.logged_in == true)
                                {
                                    chrome.tabs.create({url : (dealObject.url).replace('[user]', (loginStat.details.id)), index : tabs[0].index + 1});
                                }
                                else
                                {
                                    chrome.tabs.create({url : dealObject.url, index : tabs[0].index + 1});
                                }
                            }
                        });
                    });
                });
            });
        });
        row1.appendChild(title);
        row2.appendChild(details);
        row2.appendChild(btn);
        row3.appendChild(title.cloneNode(true));
        row3.appendChild(dDesc);
        row3.appendChild(validity);
        if(dealObject.verified_on != null)
        {
            row3.appendChild(verified);
            title.appendChild(ver_img);
        }
        deal.appendChild(row1);
        deal.appendChild(bg_img);
        deal.appendChild(row2);
        deal.appendChild(row3);
        document.getElementById("accordion").appendChild(deal);
    }
        /*********Function for adding Deal Elements Complete********/   
}
function copy(text) 
{
    const ta = document.createElement('textarea');
    ta.style.cssText = 'opacity:0; position:fixed; width:1px; height:1px; top:0; left:0;';
    ta.value = text;
    document.body.appendChild(ta);
    ta.focus();
    ta.select();
    document.execCommand('copy');
    ta.remove();
}
function setAttributes(el, attrs) {
    for(var key in attrs) {
      el.setAttribute(key, attrs[key]);
    }
  }